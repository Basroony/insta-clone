<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-05-25 12:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 12:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-05-25 12:59:52 --> 404 Page Not Found: /index
DEBUG - 2021-05-25 13:00:07 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-05-25 13:00:07 --> 404 Page Not Found: /index
DEBUG - 2021-05-25 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:00:11 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:00:11 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:00:23 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:00:23 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:00:30 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:00:30 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:00:55 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:00:55 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:00:55 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
ERROR - 2021-05-25 13:00:55 --> Severity: Notice --> Undefined property: CI::$Api_model C:\xampp\htdocs\insta-clone-be\application\third_party\MX\Controller.php 59
ERROR - 2021-05-25 13:00:55 --> Severity: error --> Exception: Call to a member function addLogApi() on null C:\xampp\htdocs\insta-clone-be\application\modules\api\controllers\Api.php 65
DEBUG - 2021-05-25 13:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:01:40 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:01:40 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:01:40 --> Total execution time: 0.0888
DEBUG - 2021-05-25 13:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:05:41 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:05:41 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:05:41 --> Total execution time: 0.1202
DEBUG - 2021-05-25 13:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:05:47 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:05:47 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:05:47 --> Total execution time: 0.0730
DEBUG - 2021-05-25 13:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:05:57 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:05:57 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 13:05:57 --> Total execution time: 0.1017
DEBUG - 2021-05-25 13:16:11 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 13:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 13:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 13:16:12 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 13:16:12 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 19:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 19:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 19:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 19:56:36 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 19:56:36 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 19:56:36 --> Total execution time: 0.4764
DEBUG - 2021-05-25 20:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:05:32 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:05:32 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:06:02 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:06:02 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:06:02 --> Total execution time: 0.0886
DEBUG - 2021-05-25 20:07:04 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:07:04 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:07:04 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:07:04 --> Total execution time: 0.0880
DEBUG - 2021-05-25 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:07:16 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:07:16 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:07:48 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:07:48 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:09:12 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:09:12 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:09:12 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:09:21 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:09:21 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:09:21 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:09:38 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:09:38 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:09:38 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:09:40 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:09:40 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:09:43 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:09:43 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:11:44 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:11:44 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:11:44 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:11:44 --> Total execution time: 0.0702
DEBUG - 2021-05-25 20:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:11:52 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:11:52 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:12:37 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:12:37 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:12:37 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:12:58 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:12:58 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:12:58 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:14:42 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:14:42 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:14:54 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:14:54 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:14:54 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:17:33 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:17:33 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:20:57 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:20:57 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:20:57 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:23:26 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:23:26 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:23:26 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:24:04 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:24:04 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:24:04 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:25:13 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:25:13 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:25:43 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:25:43 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:25:43 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:26:55 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:26:55 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:26:55 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:28:08 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:28:08 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:28:08 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
DEBUG - 2021-05-25 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-05-25 20:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-05-25 20:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-05-25 20:29:17 --> Api MX_Controller Initialized
DEBUG - 2021-05-25 20:29:17 --> File loaded: C:\xampp\htdocs\insta-clone-be\application\modules/api/models/Api_model.php
