<!DOCTYPE html>
<html lang="en">
	<?php echo $header; ?>
	<?php echo $body; ?>
</html>